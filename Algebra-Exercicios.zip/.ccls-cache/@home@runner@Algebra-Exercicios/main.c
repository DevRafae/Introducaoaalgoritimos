#include <stdio.h>

int main(){

  int x = 2, y = -5;
  float a = 3.4;

  printf("resultado é: %d\n" , (5%8
    ) );

  return 0;
}