#include <stdio.h>

int main(void) {

int n, r; //lalalala
  printf("Digite 0 se quiser falso e algo diferente de 0 se quer um valor verdadeiro, querida:\n"); scanf("%d", &n); printf("Digite algo igual a 0 para representar verdadeiro e algo diferente de 0 para representar falso, querida: "); scanf("%d", &r); if(n != 0 && r != 0){ printf("Ambos são verdadeiros, querida");} else if(n && r){ printf("ambos são falso");} else if(n ^ r){ printf("Apenas um deles é verdadeiro");}

return 0;}